package com.vndev.gamebooster;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Custom lightweight ring: percentage of system RAM used, not a fabricated FPS or boost score. */
public class RingView extends View {
    private int percent;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int fg = Color.rgb(117,243,208);
    private final int bg = Color.rgb(43,57,74);

    public RingView(Context context) { super(context); }
    public void setPercent(int percent) { this.percent=Math.min(100,Math.max(0,percent)); invalidate(); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float d=Math.min(getWidth(),getHeight());
        float stroke=d*0.09f;
        RectF arc=new RectF((getWidth()-d)/2+stroke,(getHeight()-d)/2+stroke,
            (getWidth()+d)/2-stroke,(getHeight()+d)/2-stroke);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(stroke);
        paint.setColor(bg); c.drawArc(arc,0,360,false,paint);
        paint.setColor(percent>85 ? Color.rgb(255,177,112) : fg);
        c.drawArc(arc,-90,percent*3.6f,false,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-black",android.graphics.Typeface.BOLD));
        paint.setTextSize(d*.265f);
        c.drawText(percent+"%",getWidth()/2f,getHeight()/2f+d*.075f,paint);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL));
        paint.setTextSize(d*.085f);
        paint.setColor(Color.rgb(159,175,193));
        c.drawText("RAM ĐANG DÙNG",getWidth()/2f,getHeight()/2f+d*.17f,paint);
    }
}
