package com.vndev.gamebooster;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;
import android.view.WindowManager;
import java.util.Locale;

/** Read-only system signals. They do not measure game FPS or CPU/GPU clock speeds. */
public final class DeviceStats {
    private DeviceStats() {}

    public static class Snapshot {
        public long totalRam, freeRam, freeStorage, totalStorage;
        public int battery = -1, thermal = -1;
        public float batteryC = Float.NaN, refreshRate = 0f;
        public String network = "Không rõ";
        public boolean powerSave;

        public int ramUsedPercent() {
            if (totalRam <= 0) return 0;
            return Math.min(100, Math.max(0, (int)Math.round(100.0 * (totalRam-freeRam)/totalRam)));
        }
    }

    public static Snapshot read(Context c) {
        Snapshot s = new Snapshot();
        try {
            ActivityManager am = (ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            if (am != null) {
                am.getMemoryInfo(mi);
                s.totalRam = mi.totalMem;
                s.freeRam = mi.availMem;
            }
        } catch (Exception ignored) { }
        try {
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i != null) {
                int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                if (level >= 0 && scale > 0) s.battery = Math.round(100f * level / scale);
                int temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                if (temp > 0) s.batteryC = temp/10f;
            }
        } catch (Exception ignored) { }
        try {
            PowerManager pm = (PowerManager)c.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                s.powerSave = pm.isPowerSaveMode();
                if (Build.VERSION.SDK_INT >= 29) s.thermal = pm.getCurrentThermalStatus();
            }
        } catch (Exception ignored) { }
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            s.freeStorage = sf.getAvailableBytes();
            s.totalStorage = sf.getTotalBytes();
        } catch (Exception ignored) { }
        try {
            ConnectivityManager cm = (ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                Network nw = cm.getActiveNetwork();
                NetworkCapabilities cp = nw == null ? null : cm.getNetworkCapabilities(nw);
                if (cp == null) s.network = "Ngoại tuyến";
                else if (cp.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) s.network = "Wi-Fi";
                else if (cp.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) s.network = "Dữ liệu di động";
                else if (cp.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) s.network = "Ethernet";
                else s.network = "Đã kết nối";
            }
        } catch (Exception ignored) { }
        return s;
    }

    public static String gb(long bytes) {
        if (bytes <= 0) return "—";
        return String.format(Locale.US, "%.1f GB", bytes / (1024.0*1024*1024));
    }
    public static String temperature(float value) {
        return Float.isNaN(value) ? "—" : String.format(Locale.US,"%.1f°C", value);
    }
    public static String thermalLabel(int level) {
        switch (level) {
            case 0: return "Bình thường";
            case 1: return "Nhẹ";
            case 2: return "Trung bình";
            case 3: return "Nóng";
            case 4: return "Rất nóng";
            case 5: return "Khẩn cấp";
            case 6: return "Nguy hiểm";
            default: return "Không hỗ trợ";
        }
    }
}
