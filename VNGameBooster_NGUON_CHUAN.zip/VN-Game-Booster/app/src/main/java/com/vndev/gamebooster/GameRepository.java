package com.vndev.gamebooster;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Lists user-launchable apps visible via manifest <queries>. Does not need broad package access. */
public final class GameRepository {
    private GameRepository() {}
    public static class Game {
        public String packageName, activity, name;
        public Drawable icon;
        public boolean classifiedGame;
    }

    public static List<Game> allLaunchable(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> matches = pm.queryIntentActivities(query, 0);
        ArrayList<Game> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : matches) {
            if (ri.activityInfo == null || ri.activityInfo.packageName == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(context.getPackageName()) || !seen.add(pkg)) continue;
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                Game g = new Game();
                g.packageName = pkg;
                g.activity = ri.activityInfo.name;
                g.name = ri.loadLabel(pm).toString();
                if (g.name.isEmpty()) g.name = pkg;
                g.icon = ri.loadIcon(pm);
                g.classifiedGame = ai.category == ApplicationInfo.CATEGORY_GAME;
                // OEM game categorization varies; the user can switch to All Apps.
                result.add(g);
            } catch (Exception ignored) { }
        }
        final Collator sorter = Collator.getInstance(new Locale("vi", "VN"));
        result.sort(Comparator.comparing((Game g) -> !g.classifiedGame)
                .thenComparing(g -> g.name, sorter));
        return result;
    }
}
