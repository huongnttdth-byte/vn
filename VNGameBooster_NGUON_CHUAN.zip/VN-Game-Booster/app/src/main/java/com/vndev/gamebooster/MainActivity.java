package com.vndev.gamebooster;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Switch;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * VN Game Booster: an honest, no-root game launcher and session assistant.
 * No fake FPS, no killing other apps, no hidden restricted Android APIs.
 */
public class MainActivity extends Activity {
    private static final int BG=0xFF090E17;
    private static final int CARD=0xFF172233;
    private static final int CARD_2=0xFF1B293C;
    private static final int WHITE=0xFFF4F8FF;
    private static final int MUTED=0xFF9BB0C6;
    private static final int MINT=0xFF75F3D0;
    private static final int AMBER=0xFFFFBC75;
    private static final int BLUE=0xFF82AFFF;
    private static final String[] NAV={"Tổng quan","Trò chơi","Thiết bị","Cài đặt"};
    private static final String[] NAV_ICONS={"⌂","◈","▤","⚙"};

    private LinearLayout content, navBar;
    private ScrollView scroller;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Map<String,TextView> metricNodes=new HashMap<>();
    private RingView ramRing;
    private TextView headerSignal, lastRefresh, sessionClock;
    private int tab=0;
    private boolean showAll;
    private int visibleGameLimit=40;
    private List<GameRepository.Game> apps=new ArrayList<>();
    private DeviceStats.Snapshot snapshot;
    private SharedPreferences prefs;
    private boolean built=false;

    private final Runnable updater=new Runnable() {
        @Override public void run() {
            if (!built) return;
            updateVisibleStats();
            handler.postDelayed(this,4000);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs=SessionStore.pref(this);
        showAll=prefs.getBoolean("showAll",false);
        snapshot=DeviceStats.read(this);
        apps=GameRepository.allLaunchable(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildShell();
        built=true;
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        if (built) {
            apps=GameRepository.allLaunchable(this);
            snapshot=DeviceStats.read(this);
            render();
            handler.removeCallbacks(updater);
            handler.post(updater);
        }
    }
    @Override protected void onPause() {
        handler.removeCallbacks(updater);
        super.onPause();
    }
    @Override protected void onDestroy() {
        handler.removeCallbacks(updater);
        super.onDestroy();
    }

    private int dp(float value) { return (int)(value*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private GradientDrawable stroke(int color,int radius,int edge) {
        GradientDrawable d=shape(color,radius);
        d.setStroke(dp(1),edge); return d;
    }
    private GradientDrawable gradient(int a,int b,int radius) {
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});
        d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout column() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); return c;
    }
    private LinearLayout row() {
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r;
    }
    private LinearLayout.LayoutParams lp(int w,int h,int mt,int mb) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));
        p.topMargin=dp(mt); p.bottomMargin=dp(mb); return p;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView v=new TextView(this); v.setText(s);v.setTextColor(color);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        v.setFontFeatureSettings("kern");
        v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        v.setIncludeFontPadding(false); return v;
    }
    private void vertSpace(LinearLayout c,int px) {
        View v=new View(this); c.addView(v,lp(1,px,0,0));
    }
    private LinearLayout card() {
        LinearLayout c=column(); c.setPadding(dp(18),dp(17),dp(18),dp(18));
        c.setBackground(stroke(CARD,20,0xFF29374A)); return c;
    }
    private void section(LinearLayout parent,String overline,String title,String subtitle) {
        TextView over=text(overline,10,MINT,true);over.setLetterSpacing(0.16f);
        parent.addView(over,lp(-1,-2,26,8));
        parent.addView(text(title,23,WHITE,true),lp(-1,-2,0,5));
        if (subtitle!=null && !subtitle.isEmpty()) parent.addView(text(subtitle,12,MUTED,false),lp(-1,-2,0,18));
        else vertSpace(parent,14);
    }
    private TextView button(String label, boolean primary, Runnable callback) {
        TextView b=text(label,13,primary?BG:WHITE,true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(47));
        b.setPadding(dp(15),dp(12),dp(15),dp(12));
        b.setBackground(primary?gradient(MINT,0xFFA8FFE9,13):stroke(CARD_2,13,0xFF37516D));
        b.setElevation(dp(2));
        b.setOnClickListener(v -> callback.run());
        return b;
    }
    private TextView chip(String label,int foreground,int background) {
        TextView t=text(label,11,foreground,true);
        t.setPadding(dp(10),dp(6),dp(10),dp(6));
        t.setBackground(shape(background,20));return t;
    }
    private void buildShell() {
        FrameLayout base=new FrameLayout(this);
        // Android 15+ enforces edge-to-edge for target API 35. Respect system bars.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            base.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets system = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(system.left, system.top, system.right, system.bottom);
                return insets;
            });
        }
        base.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{BG,0xFF111C2B,0xFF0A101A}));
        LinearLayout main=column();
        FrameLayout.LayoutParams m=new FrameLayout.LayoutParams(-1,-1);
        base.addView(main,m);
        LinearLayout top=row();top.setPadding(dp(20),dp(18),dp(20),dp(10));
        TextView logo=text("ϟ",31,BG,true);logo.setGravity(Gravity.CENTER);
        logo.setBackground(gradient(MINT,0xFF53C5FF,14));
        top.addView(logo,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout brand=column();
        brand.setPadding(dp(12),dp(3),0,0);
        TextView app=text("VN GAME BOOSTER",18,WHITE,true);
        app.setLetterSpacing(0.045f);
        brand.addView(app);
        brand.addView(text("PERFORMANCE COMPANION  •  V1.0",9,MUTED,true),lp(-1,-2,5,0));
        top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        headerSignal=chip("● LIVE",MINT,0xFF183D3E);
        top.addView(headerSignal);
        main.addView(top,lp(-1,-2,0,6));
        scroller=new ScrollView(this);
        scroller.setFillViewport(false);
        scroller.setVerticalScrollBarEnabled(false);
        scroller.setClipToPadding(false);
        content=column();
        content.setPadding(dp(18),0,dp(18),dp(25));
        scroller.addView(content,new ScrollView.LayoutParams(-1,-2));
        main.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        navBar=row();navBar.setGravity(Gravity.CENTER);
        navBar.setPadding(dp(6),dp(9),dp(6),dp(10));
        navBar.setBackground(stroke(0xFF101927,22,0xFF27384C));
        LinearLayout.LayoutParams navlp=lp(-1,-2,0,0);
        navlp.leftMargin=dp(12);navlp.rightMargin=dp(12);navlp.bottomMargin=dp(10);
        main.addView(navBar,navlp);
        setContentView(base);
    }
    private void renderNav() {
        navBar.removeAllViews();
        for (int i=0;i<NAV.length;i++) {
            final int index=i;
            boolean chosen=i==tab;
            LinearLayout entry=column();entry.setGravity(Gravity.CENTER);
            entry.setPadding(dp(1),dp(5),dp(1),dp(5));
            entry.setBackground(shape(chosen?0xFF203D43:0x00101927,14));
            TextView sym=text(NAV_ICONS[i],24,chosen?MINT:MUTED,true);sym.setGravity(Gravity.CENTER);
            entry.addView(sym,lp(-1,-2,0,4));
            TextView label=text(NAV[i],10,chosen?WHITE:MUTED,chosen);
            label.setGravity(Gravity.CENTER);
            entry.addView(label);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(58),1);
            p.leftMargin=dp(2);p.rightMargin=dp(2);
            navBar.addView(entry,p);
            entry.setOnClickListener(v->{if(tab!=index){tab=index;render();scroller.scrollTo(0,0);}});
        }
    }
    private void render() {
        if (!built) return;
        metricNodes.clear();ramRing=null;sessionClock=null;lastRefresh=null;
        content.removeAllViews();
        renderNav();
        switch (tab) {
            case 0: home();break;
            case 1: games();break;
            case 2: monitor();break;
            default: settings();break;
        }
        updateVisibleStats();
    }
    private void go(int t) {tab=t;render();scroller.scrollTo(0,0);}
    private void twoButtons(LinearLayout parent,String left,Runnable l,String right,Runnable r) {
        LinearLayout line=row();
        TextView a=button(left,true,l);
        TextView b=button(right,false,r);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);
        p.rightMargin=dp(6);line.addView(a,p);
        LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(48),1);
        q.leftMargin=dp(6);line.addView(b,q);
        parent.addView(line,lp(-1,-2,15,0));
    }
    private void home() {
        section(content,"BẢNG ĐIỀU KHIỂN","Sẵn sàng vào trận?","Kiểm tra trạng thái máy và mở game chỉ với một chạm.");
        LinearLayout hero=card();
        hero.setBackground(gradient(0xFF173646,0xFF17243B,22));
        LinearLayout line=row();
        RingView ring=new RingView(this);ramRing=ring;
        line.addView(ring,new LinearLayout.LayoutParams(dp(132),dp(132)));
        LinearLayout info=column();info.setPadding(dp(12),dp(4),0,0);
        info.addView(chip("● ĐANG GIÁM SÁT",MINT,0xFF174444),lp(-2,-2,0,11));
        info.addView(text("TỔNG QUAN RAM",18,WHITE,true),lp(-1,-2,0,7));
        info.addView(text("Hiển thị mức sử dụng RAM thực tế của hệ thống.",12,MUTED,false));
        line.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        hero.addView(line);
        View sep=new View(this);sep.setBackgroundColor(0xFF335262);
        hero.addView(sep,lp(-1,1,14,14));
        TextView advice=text("Không có ứng dụng nào đảm bảo tăng FPS cho mọi trò chơi. Chế độ tập trung giúp giảm thông báo làm gián đoạn.",12,WHITE,false);
        advice.setLineSpacing(dp(3),1);hero.addView(advice);
        content.addView(hero,lp(-1,-2,0,16));

        metricGrid();
        LinearLayout chosen=card();
        TextView h=text("TRÒ CHƠI ĐÃ CHỌN",11,MUTED,true);h.setLetterSpacing(.1f);
        chosen.addView(h,lp(-1,-2,0,10));
        GameRepository.Game selected=selectedGame();
        LinearLayout gameRow=row();
        if(selected!=null) {
            ImageView icon=new ImageView(this);icon.setImageDrawable(selected.icon);
            gameRow.addView(icon,new LinearLayout.LayoutParams(dp(49),dp(49)));
        } else {
            TextView icon=text("◈",26,MINT,true);icon.setGravity(Gravity.CENTER);
            icon.setBackground(shape(0xFF24384A,13));
            gameRow.addView(icon,new LinearLayout.LayoutParams(dp(49),dp(49)));
        }
        LinearLayout nameBox=column();nameBox.setPadding(dp(12),dp(3),0,0);
        nameBox.addView(text(selected!=null?selected.name:"Chưa chọn trò chơi",17,WHITE,true));
        nameBox.addView(text(selected!=null?"Nhấn CHƠI NGAY để khởi chạy":"Chọn trong danh sách ứng dụng",11,MUTED,false),lp(-1,-2,7,0));
        gameRow.addView(nameBox,new LinearLayout.LayoutParams(0,-2,1));
        chosen.addView(gameRow);
        if (SessionStore.started(this)>0) {
            TextView active=chip("● PHIÊN ĐANG CHẠY",MINT,0xFF183D3E);
            chosen.addView(active,lp(-2,-2,13,8));
            sessionClock=text("Đang tính thời gian…",12,WHITE,false);
            chosen.addView(sessionClock,lp(-1,-2,0,0));
            twoButtons(chosen,"KẾT THÚC PHIÊN",this::endSession,"CHỌN GAME",()->go(1));
        } else {
            twoButtons(chosen,"ϟ  CHƠI NGAY",this::launchSelected,"CHỌN GAME",()->go(1));
        }
        content.addView(chosen,lp(-1,-2,0,16));

        LinearLayout focus=card();
        LinearLayout focusTop=row();
        LinearLayout focusCopy=column();
        focusCopy.addView(text("◉  CHẾ ĐỘ TẬP TRUNG",14,WHITE,true));
        focusCopy.addView(text("Giảm gián đoạn từ thông báo khi chơi",11,MUTED,false),lp(-1,-2,6,0));
        focusTop.addView(focusCopy,new LinearLayout.LayoutParams(0,-2,1));
        focusTop.addView(chip(isFocusOwned()?"ĐANG BẬT":"TÙY CHỌN",isFocusOwned()?MINT:MUTED,
                isFocusOwned()?0xFF19453B:0xFF293A4D));
        focus.addView(focusTop);
        focus.addView(button(isFocusOwned()?"TẮT TẬP TRUNG":"BẬT TẬP TRUNG",false,()->{
            if(isFocusOwned()) stopFocus(); else startFocusInteractive(); render();
        }),lp(-1,-2,13,0));
        content.addView(focus,lp(-1,-2,0,6));
        lastRefresh=text("Dữ liệu thiết bị sẽ cập nhật tự động.",10,MUTED,false);
        lastRefresh.setGravity(Gravity.CENTER);
        content.addView(lastRefresh,lp(-1,-2,12,0));
    }
    private void metricGrid() {
        LinearLayout a=row(),b=row();
        weighted(a,metric("RAM KHẢ DỤNG","ram","—","Còn trống",MINT),0);
        weighted(a,metric("PIN","battery","—","Dung lượng",BLUE),1);
        weighted(b,metric("NHIỆT ĐỘ PIN","temperature","—","Không phải nhiệt CPU",AMBER),0);
        weighted(b,metric("BỘ NHỚ TRỐNG","storage","—","Bộ nhớ trong",MINT),1);
        content.addView(a,lp(-1,-2,0,10));
        content.addView(b,lp(-1,-2,0,16));
    }
    private void weighted(LinearLayout line,View item,int side) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);
        if(side==0) p.rightMargin=dp(5); else p.leftMargin=dp(5);
        line.addView(item,p);
    }
    private LinearLayout metric(String heading,String key,String value,String subtitle,int accent) {
        LinearLayout m=column();m.setPadding(dp(14),dp(17),dp(12),dp(16));
        m.setBackground(stroke(CARD,18,0xFF29374A));m.setMinimumHeight(dp(116));
        TextView head=text(heading,10,MUTED,true);head.setLetterSpacing(.07f);
        m.addView(head);
        TextView val=text(value,23,accent,true);
        m.addView(val,lp(-1,-2,11,7));
        m.addView(text(subtitle,10,MUTED,false));
        metricNodes.put(key,val);
        return m;
    }
    private GameRepository.Game selectedGame() {
        String target=prefs.getString("selectedPackage","");
        for(GameRepository.Game a:apps) if(a.packageName.equals(target)) return a;
        return null;
    }
    private void games() {
        section(content,"GAME LIBRARY","Trò chơi của bạn","Chọn một ứng dụng để khởi chạy từ VN Game Booster.");
        LinearLayout selectedCard=card();
        GameRepository.Game selected=selectedGame();
        selectedCard.addView(text("ĐÃ CHỌN",10,MINT,true));
        selectedCard.addView(text(selected==null?"Chưa có trò chơi":selected.name,20,WHITE,true),lp(-1,-2,9,8));
        selectedCard.addView(text("Ứng dụng chỉ mở game bằng launcher chuẩn Android; không sửa dữ liệu của game.",11,MUTED,false));
        selectedCard.addView(button("ϟ  MỞ GAME",true,this::launchSelected),lp(-1,-2,15,0));
        content.addView(selectedCard,lp(-1,-2,0,16));
        LinearLayout options=row();
        options.addView(text(showAll?"HIỂN THỊ MỌI ỨNG DỤNG":"CHỈ APP NHẬN DIỆN LÀ GAME",11,MUTED,true),
                new LinearLayout.LayoutParams(0,-2,1));
        TextView toggle=chip(showAll?"TẤT CẢ":"GAME",MINT,0xFF204340);
        options.addView(toggle);
        options.setOnClickListener(v->{showAll=!showAll;prefs.edit().putBoolean("showAll",showAll).apply();render();});
        content.addView(options,lp(-1,-2,4,15));
        EditText search=new EditText(this);
        search.setSingleLine(true);search.setTextSize(14);search.setTextColor(WHITE);
        search.setHintTextColor(MUTED);search.setHint("⌕  Tìm game / ứng dụng...");
        search.setPadding(dp(16),dp(13),dp(16),dp(13));
        search.setBackground(stroke(CARD,14,0xFF34485E));
        content.addView(search,lp(-1,50,0,15));
        LinearLayout list=column();content.addView(list,lp(-1,-2,0,0));
        Runnable populate=()->populateApps(list,search.getText().toString());
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) { }
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                visibleGameLimit=40;populate.run();
            }
            @Override public void afterTextChanged(Editable e) { }
        });
        populate.run();
    }
    private Set<String> favorites() {
        return new HashSet<>(prefs.getStringSet("favorites",new HashSet<>()));
    }
    private void toggleFavorite(String pkg) {
        Set<String> fav=favorites();
        if(!fav.remove(pkg)) fav.add(pkg);
        prefs.edit().putStringSet("favorites",fav).apply();render();
    }
    private void populateApps(LinearLayout list,String query) {
        list.removeAllViews();
        List<GameRepository.Game> filtered=new ArrayList<>();
        String q=query.trim().toLowerCase(Locale.ROOT);
        Set<String> fav=favorites();
        for(GameRepository.Game a:apps) {
            if(!showAll && !a.classifiedGame && !fav.contains(a.packageName)) continue;
            if(!a.name.toLowerCase(Locale.ROOT).contains(q) && !a.packageName.toLowerCase(Locale.ROOT).contains(q)) continue;
            filtered.add(a);
        }
        filtered.sort(Comparator.comparing((GameRepository.Game a)->!fav.contains(a.packageName))
                .thenComparing(a->!a.classifiedGame).thenComparing(a->a.name.toLowerCase(Locale.ROOT)));
        list.addView(text(filtered.size()+" ứng dụng phù hợp"+(showAll?"":" · Chưa thấy game? Chọn TẤT CẢ"),
                11,MUTED,false),lp(-1,-2,0,12));
        if(filtered.isEmpty()) {
            LinearLayout empty=card();
            empty.addView(text("Không có ứng dụng phù hợp",16,WHITE,true));
            empty.addView(text("Một số trò chơi không được Android gắn nhãn GAME. Chuyển sang TẤT CẢ để chọn thủ công.",12,MUTED,false),lp(-1,-2,10,0));
            list.addView(empty,lp(-1,-2,0,0));
            return;
        }
        int limit=Math.min(visibleGameLimit,filtered.size());
        for(int i=0;i<limit;i++) {
            GameRepository.Game app=filtered.get(i);
            LinearLayout item=row();item.setPadding(dp(12),dp(12),dp(12),dp(12));
            item.setBackground(stroke(CARD,15,0xFF29374A));
            ImageView image=new ImageView(this);image.setImageDrawable(app.icon);
            item.addView(image,new LinearLayout.LayoutParams(dp(43),dp(43)));
            LinearLayout details=column();details.setPadding(dp(12),0,dp(5),0);
            details.addView(text(app.name,14,WHITE,true));
            String sub=app.classifiedGame?"GAME · ":"ỨNG DỤNG · ";
            String pkg=app.packageName;
            details.addView(text(sub+(pkg.length()>30?pkg.substring(0,27)+"…":pkg),10,MUTED,false),lp(-1,-2,6,0));
            item.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            TextView star=text(fav.contains(app.packageName)?"★":"☆",27,fav.contains(app.packageName)?AMBER:MUTED,true);
            star.setGravity(Gravity.CENTER);
            item.addView(star,new LinearLayout.LayoutParams(dp(38),dp(42)));
            star.setOnClickListener(v->toggleFavorite(app.packageName));
            boolean chosen=prefs.getString("selectedPackage","").equals(app.packageName);
            TextView choose=chip(chosen?"ĐÃ CHỌN":"CHỌN",chosen?BG:MINT,chosen?MINT:0xFF233E41);
            item.addView(choose);
            choose.setOnClickListener(v->{prefs.edit().putString("selectedPackage",app.packageName).apply();render();});
            item.setOnClickListener(v->{prefs.edit().putString("selectedPackage",app.packageName).apply();render();});
            list.addView(item,lp(-1,-2,0,9));
        }
        if(filtered.size()>limit) {
            list.addView(button("XEM THÊM ("+(filtered.size()-limit)+")",false,
                    ()->{visibleGameLimit+=40;populateApps(list,query);}),lp(-1,-2,6,10));
        }
    }
    private void launchSelected() {
        GameRepository.Game game=selectedGame();
        if(game==null) {Toast.makeText(this,"Hãy chọn game trước.",Toast.LENGTH_SHORT).show();go(1);return;}
        if(SessionStore.started(this)>0 && !game.name.equals(SessionStore.currentGame(this))) {
            new AlertDialog.Builder(this).setTitle("Một phiên đang hoạt động")
                .setMessage("Hãy kết thúc phiên hiện tại trước khi mở game khác.")
                .setPositiveButton("Đã hiểu",null).show();return;
        }
        boolean startedNow=SessionStore.started(this)==0;
        if(startedNow) {
            SessionStore.begin(this,game.name);
            if (prefs.getBoolean("autoFocus",false)) {
                if(!startFocus(false)) Toast.makeText(this,"Chưa kích hoạt tập trung; vẫn mở game.",Toast.LENGTH_LONG).show();
            }
        }
        try {
            Intent intent=getPackageManager().getLaunchIntentForPackage(game.packageName);
            if(intent==null) {
                intent=new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                intent.setClassName(game.packageName,game.activity);
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch(Exception e) {
            if(startedNow){SessionStore.end(this);stopFocus();}
            new AlertDialog.Builder(this).setTitle("Không thể mở game")
                    .setMessage("Android đã từ chối mở "+game.name+".\n"+e.getMessage())
                    .setPositiveButton("Đóng",null).show();
        }
    }
    private void endSession() {
        SessionStore.end(this);stopFocus();
        Toast.makeText(this,"Đã lưu phiên chơi.",Toast.LENGTH_SHORT).show();render();
    }
    private boolean isFocusOwned() {return prefs.getBoolean("focusOwned",false);}
    private boolean focusAccess() {
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        return nm!=null && nm.isNotificationPolicyAccessGranted();
    }
    private void requestFocusAccess() {
        new AlertDialog.Builder(this)
                .setTitle("Cấp quyền chế độ tập trung")
                .setMessage("Android yêu cầu bạn cấp quyền 'Không làm phiền'. Chế độ này có thể tắt âm thanh thông báo. Bạn có thể tắt lại trong ứng dụng hoặc Cài đặt hệ thống.")
                .setPositiveButton("MỞ CÀI ĐẶT",(d,w)->openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                .setNegativeButton("ĐỂ SAU",null).show();
    }
    private boolean startFocus(boolean interactive) {
        if(!focusAccess()) {
            if(interactive) requestFocusAccess();
            return false;
        }
        try {
            NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm==null)return false;
            if(isFocusOwned())return true;
            if(nm.getCurrentInterruptionFilter()!=NotificationManager.INTERRUPTION_FILTER_ALL) {
                // Another DND rule is already active; do not take ownership or disable it later.
                Toast.makeText(this,"Chế độ Không làm phiền đã được bật trong hệ thống.",Toast.LENGTH_SHORT).show();
                return true;
            }
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            prefs.edit().putBoolean("focusOwned",true).apply();
            return true;
        } catch(Exception e) {
            Toast.makeText(this,"Không thể bật tập trung trên máy này.",Toast.LENGTH_LONG).show();
            return false;
        }
    }
    private void startFocusInteractive() {startFocus(true);}
    private void stopFocus() {
        if(!isFocusOwned()) return;
        try {
            NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null && nm.isNotificationPolicyAccessGranted())
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
        } catch(Exception e) {
            Toast.makeText(this,"Hãy tắt Không làm phiền trong Cài đặt hệ thống.",Toast.LENGTH_LONG).show();
        }
        prefs.edit().putBoolean("focusOwned",false).apply();
    }
    private void monitor() {
        section(content,"LIVE DEVICE HEALTH","Trạng thái thiết bị","Số liệu đọc từ API hệ thống, không phải FPS trong game.");
        LinearLayout head=card();head.setBackground(gradient(0xFF162B3F,0xFF192439,19));
        head.addView(text("GIÁM SÁT THỜI GIAN THỰC",11,MINT,true));
        head.addView(text("Thông tin cập nhật mỗi 4 giây khi ứng dụng đang mở.",12,WHITE,false),lp(-1,-2,10,11));
        lastRefresh=text("Đang cập nhật…",11,MUTED,false);head.addView(lastRefresh);
        content.addView(head,lp(-1,-2,0,16));
        LinearLayout r1=row(),r2=row(),r3=row(),r4=row(),r5=row();
        weighted(r1,metric("RAM KHẢ DỤNG","ram","—","RAM hệ thống",MINT),0);
        weighted(r1,metric("RAM ĐANG DÙNG","ramUsed","—","Tỷ lệ ước tính",BLUE),1);
        weighted(r2,metric("PIN","battery","—","Dung lượng pin",BLUE),0);
        weighted(r2,metric("NHIỆT ĐỘ PIN","temperature","—","Đo qua cảm biến pin",AMBER),1);
        weighted(r3,metric("NHIỆT HỆ THỐNG","thermal","—","Chỉ báo Android",AMBER),0);
        weighted(r3,metric("BỘ NHỚ TRỐNG","storage","—","Bộ nhớ dữ liệu",MINT),1);
        weighted(r4,metric("KẾT NỐI","network","—","Loại mạng",BLUE),0);
        weighted(r4,metric("TIẾT KIỆM PIN","batterySaver","—","Trạng thái hệ thống",AMBER),1);
        content.addView(r1,lp(-1,-2,0,10));content.addView(r2,lp(-1,-2,0,10));
        weighted(r5,metric("TẦN SỐ MÀN HÌNH","refresh","—","Không phải FPS game",BLUE),0);
        weighted(r5,metric("RAM TỔNG","ramTotal","—","Dung lượng hệ thống",MINT),1);
        content.addView(r3,lp(-1,-2,0,10));content.addView(r4,lp(-1,-2,0,10));
        content.addView(r5,lp(-1,-2,0,16));
        LinearLayout tips=card();
        tips.addView(text("ĐỀ XUẤT THEO TRẠNG THÁI MÁY",12,MINT,true));
        TextView advice=text(recommendation(snapshot),13,WHITE,false);advice.setLineSpacing(dp(5),1);
        tips.addView(advice,lp(-1,-2,11,0));
        metricNodes.put("advice",advice);
        content.addView(tips,lp(-1,-2,0,16));
        content.addView(button("MỞ CÀI ĐẶT PIN",false,
                ()->openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS)),lp(-1,-2,0,8));
        content.addView(button("MỞ CÀI ĐẶT KẾT NỐI",false,
                ()->openSettings(Settings.ACTION_WIFI_SETTINGS)),lp(-1,-2,0,0));
    }
    private String recommendation(DeviceStats.Snapshot s) {
        StringBuilder b=new StringBuilder();
        if(s.thermal>=3 || (!Float.isNaN(s.batteryC)&&s.batteryC>=42))
            b.append("• Máy đang nóng: giảm đồ họa/FPS trong game, tháo ốp nếu phù hợp và nghỉ cho máy nguội.\n");
        if(s.battery>=0&&s.battery<20)
            b.append("• Pin yếu: cân nhắc cắm sạc phù hợp hoặc giảm độ sáng màn hình.\n");
        if(s.freeRam>0&&s.freeRam<1024L*1024*1024)
            b.append("• RAM còn dưới 1 GB: đóng các ứng dụng không cần thiết bằng trình đa nhiệm.\n");
        if(s.powerSave)
            b.append("• Đang bật tiết kiệm pin: hiệu năng có thể bị giới hạn; cân nhắc tắt nếu muốn ưu tiên chơi game.\n");
        if("Dữ liệu di động".equals(s.network))
            b.append("• Bạn đang dùng mạng di động: Wi-Fi ổn định có thể giúp hạn chế dao động độ trễ.\n");
        if(b.length()==0) b.append("• Chưa có cảnh báo lớn từ các cảm biến được Android cung cấp.\n");
        b.append("• Muốn FPS ổn định hơn, hãy giảm hiệu ứng/đổ bóng trong cài đặt game và dùng Game Mode của hãng nếu máy hỗ trợ.");
        return b.toString();
    }
    private void settings() {
        section(content,"TÙY CHỈNH","Chế độ & công cụ","Tối ưu trải nghiệm mà không cần root hoặc quyền nguy hiểm.");
        LinearLayout mode=card();
        mode.addView(text("CHẾ ĐỘ CHƠI",12,MINT,true));
        String[] titles={"◉  CÂN BẰNG","◈  TẬP TRUNG","❄  GIỮ MÁT"};
        String[] descriptions={"Mở game bình thường, theo dõi phiên chơi.",
            "Ưu tiên hạn chế thông báo khi có quyền.",
            "Khuyến nghị giảm độ sáng và thiết lập đồ họa."};
        int current=prefs.getInt("profile",0);
        for(int i=0;i<3;i++) {
            final int index=i;
            LinearLayout option=row();option.setPadding(dp(13),dp(13),dp(13),dp(13));
            option.setBackground(stroke(i==current?0xFF204544:CARD_2,12,
                    i==current?MINT:0xFF31445B));
            LinearLayout copy=column();
            copy.addView(text(titles[i],13,i==current?MINT:WHITE,true));
            copy.addView(text(descriptions[i],11,MUTED,false),lp(-1,-2,6,0));
            option.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            option.addView(text(i==current?"●":"○",21,i==current?MINT:MUTED,true));
            mode.addView(option,lp(-1,-2,11,0));
            option.setOnClickListener(v->{
                prefs.edit().putInt("profile",index).apply();
                prefs.edit().putBoolean("autoFocus",index==1).apply();
                if(index==1 && !focusAccess())requestFocusAccess();
                render();
            });
        }
        content.addView(mode,lp(-1,-2,0,16));
        LinearLayout focus=card();
        focus.addView(text("THIẾT LẬP PHIÊN CHƠI",12,MINT,true));
        LinearLayout toggle=row();toggle.setPadding(0,dp(13),0,dp(8));
        LinearLayout copy=column();
        copy.addView(text("Tự bật tập trung khi mở game",14,WHITE,true));
        copy.addView(text("Cần cấp quyền Không làm phiền trong Android",11,MUTED,false),lp(-1,-2,7,0));
        toggle.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        Switch focusSwitch=new Switch(this);focusSwitch.setChecked(prefs.getBoolean("autoFocus",false));
        focusSwitch.setOnCheckedChangeListener((b,checked)->{
            prefs.edit().putBoolean("autoFocus",checked).apply();
            if(checked&&!focusAccess())requestFocusAccess();
        });
        toggle.addView(focusSwitch);
        focus.addView(toggle);
        focus.addView(button("QUẢN LÝ QUYỀN KHÔNG LÀM PHIỀN",false,
                ()->openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)),lp(-1,-2,10,0));
        content.addView(focus,lp(-1,-2,0,16));
        LinearLayout quick=card();
        quick.addView(text("LỐI TẮT CÀI ĐẶT HỆ THỐNG",12,MINT,true));
        settingEntry(quick,"◐","Màn hình & độ sáng","Điều chỉnh độ sáng và tần số quét nếu có",Settings.ACTION_DISPLAY_SETTINGS);
        settingEntry(quick,"◈","Tiết kiệm pin","Kiểm soát chế độ nguồn của Android",Settings.ACTION_BATTERY_SAVER_SETTINGS);
        settingEntry(quick,"⌁","Wi-Fi","Chọn kết nối ổn định để giảm dao động ping",Settings.ACTION_WIFI_SETTINGS);
        settingEntry(quick,"⚙","Thông tin ứng dụng","Mở trang quyền và thông tin VN Game Booster",null);
        content.addView(quick,lp(-1,-2,0,16));

        LinearLayout hist=card();hist.addView(text("LỊCH SỬ CHƠI GẦN ĐÂY",12,MINT,true));
        JSONArray records=SessionStore.history(this);
        if(records.length()==0) hist.addView(text("Chưa có phiên chơi nào được kết thúc.",12,MUTED,false),lp(-1,-2,13,0));
        SimpleDateFormat formatter=new SimpleDateFormat("dd/MM/yyyy  HH:mm",Locale.forLanguageTag("vi-VN"));
        for(int i=0;i<Math.min(8,records.length());i++) {
            try {
                JSONObject obj=records.getJSONObject(i);
                String name=obj.optString("name","Game");
                long st=obj.optLong("start"),en=obj.optLong("end");
                LinearLayout item=column();item.setPadding(0,dp(12),0,dp(8));
                item.addView(text(name,13,WHITE,true));
                item.addView(text(formatter.format(new Date(st))+"  •  "+SessionStore.duration(en-st),11,MUTED,false),lp(-1,-2,6,0));
                hist.addView(item);
            }catch(Exception ignored) { }
        }
        content.addView(hist,lp(-1,-2,0,16));
        content.addView(text("VN GAME BOOSTER v1.0 · Không thu thập dữ liệu cá nhân, không gửi thống kê lên máy chủ, không đo FPS của ứng dụng khác.",11,MUTED,false),lp(-1,-2,0,12));
    }
    private void settingEntry(LinearLayout parent,String symbol,String title,String description,String action) {
        LinearLayout item=row();item.setPadding(dp(3),dp(14),dp(2),dp(13));
        TextView icon=text(symbol,24,BLUE,true);icon.setGravity(Gravity.CENTER);
        item.addView(icon,new LinearLayout.LayoutParams(dp(40),dp(38)));
        LinearLayout info=column();
        info.addView(text(title,13,WHITE,true));
        info.addView(text(description,10,MUTED,false),lp(-1,-2,6,0));
        item.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        item.addView(text("›",26,MUTED,false));
        item.setOnClickListener(v->{
            if(action!=null) openSettings(action);
            else {
                Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:"+getPackageName()));
                try{startActivity(i);}catch(Exception e){toast("Không mở được cài đặt ứng dụng.");}
            }
        });
        parent.addView(item);
    }
    private void openSettings(String action) {
        try {startActivity(new Intent(action));}
        catch(Exception e){
            try{startActivity(new Intent(Settings.ACTION_SETTINGS));}
            catch(Exception ignored){toast("Thiết bị không hỗ trợ lối tắt này.");}
        }
    }
    private void toast(String msg) {Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();}
    private void updateVisibleStats() {
        snapshot=DeviceStats.read(this);
        if(ramRing!=null)ramRing.setPercent(snapshot.ramUsedPercent());
        setMetric("ram",DeviceStats.gb(snapshot.freeRam));
        setMetric("ramUsed",snapshot.ramUsedPercent()+"%");
        setMetric("ramTotal",DeviceStats.gb(snapshot.totalRam));
        setMetric("refresh",snapshot.refreshRate>0?String.format(Locale.US,"%.0f Hz",snapshot.refreshRate):"—");
        setMetric("battery",snapshot.battery<0?"—":snapshot.battery+"%");
        setMetric("temperature",DeviceStats.temperature(snapshot.batteryC));
        setMetric("thermal",DeviceStats.thermalLabel(snapshot.thermal));
        setMetric("storage",DeviceStats.gb(snapshot.freeStorage));
        setMetric("network",snapshot.network);
        setMetric("batterySaver",snapshot.powerSave?"Đang bật":"Đã tắt");
        setMetric("advice",recommendation(snapshot));
        if(lastRefresh!=null)
            lastRefresh.setText("● Dữ liệu cập nhật lúc "+new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date()));
        if(sessionClock!=null && SessionStore.started(this)>0)
            sessionClock.setText(SessionStore.currentGame(this)+" · "+SessionStore.duration(System.currentTimeMillis()-SessionStore.started(this)));
        if(headerSignal!=null) headerSignal.setText(snapshot.thermal>=3?"● NÓNG":"● LIVE");
    }
    private void setMetric(String key,String value) {
        TextView t=metricNodes.get(key);
        if(t!=null)t.setText(value);
    }
}
