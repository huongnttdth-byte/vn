package com.vndev.gamebooster;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Session timestamps persist even if Android terminates the booster while a game runs. */
public final class SessionStore {
    private static final String PREF = "vn_booster_prefs";
    private SessionStore() {}

    public static SharedPreferences pref(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
    public static long started(Context c) { return pref(c).getLong("sessionStart", 0L); }
    public static String currentGame(Context c) { return pref(c).getString("sessionName", ""); }
    public static void begin(Context c, String name) {
        pref(c).edit().putLong("sessionStart",System.currentTimeMillis())
                .putString("sessionName",name).apply();
    }
    public static void end(Context c) {
        SharedPreferences p = pref(c);
        long start = p.getLong("sessionStart",0);
        if (start == 0) return;
        long end = System.currentTimeMillis();
        JSONArray a;
        try { a = new JSONArray(p.getString("history","[]")); }
        catch (Exception e) { a = new JSONArray(); }
        try {
            JSONObject item = new JSONObject();
            item.put("name",p.getString("sessionName","Game"));
            item.put("start",start);
            item.put("end",Math.max(start,end));
            JSONArray next = new JSONArray();
            next.put(item);
            for (int i=0;i<Math.min(a.length(),24);i++) next.put(a.getJSONObject(i));
            p.edit().remove("sessionStart").remove("sessionName")
                    .putString("history",next.toString()).apply();
        } catch (Exception ignored) {
            p.edit().remove("sessionStart").remove("sessionName").apply();
        }
    }
    public static JSONArray history(Context c) {
        try { return new JSONArray(pref(c).getString("history","[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    public static String duration(long ms) {
        long m = Math.max(0,ms)/60000;
        long h = m/60;
        return h > 0 ? h+" giờ "+(m%60)+" phút" : m+" phút";
    }
}
