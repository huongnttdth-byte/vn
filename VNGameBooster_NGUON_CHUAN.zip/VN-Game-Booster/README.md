# VN Game Booster · Android

Ứng dụng hỗ trợ chơi game cho Android 8.0+ (API 26+), viết **Java thuần**, giao diện native Android tối hiện đại, không phụ thuộc thư viện UI bên ngoài, không root, không máy chủ.

## Tính năng thực tế

- **Dashboard:** RAM đang dùng, RAM còn trống, dung lượng pin, nhiệt độ pin, dung lượng bộ nhớ trống.
- **Game Library:** phát hiện ứng dụng được Android đánh dấu `CATEGORY_GAME`; chuyển sang **TẤT CẢ** để chọn game không có nhãn; tìm kiếm, ghim yêu thích, chọn và mở game bằng launcher chuẩn.
- **Focus:** xin quyền Không làm phiền minh bạch; bật/tắt chế độ ưu tiên thông báo; tùy chọn bật khi bắt đầu game; tắt chế độ do ứng dụng bật khi kết thúc phiên.
- **Session:** ghi nhớ thời gian bắt đầu ngay cả khi Android đóng tiến trình app, kết thúc phiên thủ công, lưu tối đa 25 phiên gần nhất.
- **Device monitor:** RAM, pin, nhiệt độ pin, thermal status hệ thống (API 29+), dung lượng bộ nhớ, loại kết nối, tiết kiệm pin; cập nhật mỗi 4 giây khi đang xem ứng dụng.
- **Profiles:** Cân bằng, Tập trung, Giữ mát (là preset điều hành/thông tin; không ép xung).
- **Quick settings:** mở trực tiếp trang màn hình, kết nối Wi-Fi, tiết kiệm pin, cấp quyền DND.
- **Khuyến nghị theo dữ liệu:** thông báo khi máy nóng, pin yếu, RAM ít, đang bật tiết kiệm pin hoặc dùng mạng di động.

## Những điều KHÔNG làm

Không giả lập số FPS hay "tăng 200% FPS"; không đọc tốc độ khung hình của game khác; không tăng xung CPU/GPU; không tự kết thúc ứng dụng khác; không vô hiệu hóa throttling nhiệt; không can thiệp dữ liệu game. Android không cho ứng dụng bình thường quyền làm những điều đó trên các thiết bị không root.

Giá trị **nhiệt độ pin** khác với nhiệt độ CPU; `PowerManager.getCurrentThermalStatus()` là mức nhiệt do Android phân loại, có thể không được OEM cung cấp. **RAM hệ thống** khác bộ nhớ game. Profile **Giữ mát** hướng dẫn người dùng thay đổi cài đặt phù hợp chứ không làm mát phần cứng.

## Tạo file APK bằng Android Studio

**Yêu cầu:** Android Studio có kết nối Internet để tải Gradle plugin lần đầu, JDK 17, Android SDK 35. Ứng dụng được cấu hình với AGP 8.7.3, Gradle 8.9 và Java 17.

1. Giải nén thư mục `VN-Game-Booster`.
2. Trong Android Studio, chọn **Open** rồi trỏ đến thư mục chứa `settings.gradle`.
3. Chờ **Gradle Sync** hoàn tất; nếu được hỏi, cài Android SDK API 35.
4. Chọn menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. File tạo ra nằm tại `app/build/outputs/apk/debug/app-debug.apk`.
6. Chuyển APK sang điện thoại Android, cài đặt sau khi cấp quyền cài từ nguồn được chọn. Đây là APK debug tự ký phục vụ thử nghiệm, không phải bản phát hành Play Store.

**Cách khác: build tự động trên GitHub Actions**

1. Tạo một GitHub repository và đẩy **toàn bộ nội dung thư mục này** lên nhánh `main`.
2. Vào tab **Actions > Build Android APK > Run workflow**.
3. Mở kết quả chạy thành công và tải artifact tên `VN-Game-Booster-debug-APK`.
4. Giải nén artifact để lấy `app-debug.apk`.

Mã workflow nằm trong `.github/workflows/build-apk.yml`. Không cần Android SDK trên máy nếu dùng GitHub Actions.

## Quyền và riêng tư

| Quyền | Mục đích |
|---|---|
| `ACCESS_NETWORK_STATE` | Cho biết loại mạng, không đo ping hay theo dõi dữ liệu truy cập. |
| `ACCESS_NOTIFICATION_POLICY` | Khi người dùng cấp quyền ở Cài đặt, điều khiển chế độ tập trung. |
| `<queries>` ứng dụng launcher | Xem danh sách ứng dụng có thể mở, không xin `QUERY_ALL_PACKAGES`. |

Không có `INTERNET`, `PACKAGE_USAGE_STATS`, `KILL_BACKGROUND_PROCESSES`, `SYSTEM_ALERT_WINDOW` hay quyền truy cập tệp cá nhân. Cài đặt, game được chọn và lịch sử phiên được lưu cục bộ trong SharedPreferences, không đồng bộ ra ngoài.

## Ghi chú tương thích

- **Android 8+**; Android 10+ có phân loại trạng thái nhiệt hệ thống nếu thiết bị hỗ trợ.
- **Android 15+** thay đổi cách xử lý DND, gọi `setInterruptionFilter` có thể tạo / bật một quy tắc Zen do ứng dụng quản lý. Kết quả cuối còn tùy các quy tắc DND của máy.
- Cấu hình Game Mode do **game/OEM/hệ thống** quản lý; launcher này không tự thay đổi game mode của game khác.
- Chức năng liệt kê game dựa vào metadata Android, nên game không được nhận diện cần bật **TẤT CẢ** và chọn thủ công.
- Số phút chơi là từ lúc nhấn mở game đến khi nhấn **KẾT THÚC PHIÊN** trong app, không phải thời gian foreground thực tế của game.

## Cấu trúc nguồn

```
VN-Game-Booster/
├── app/build.gradle
├── app/src/main/AndroidManifest.xml
├── app/src/main/java/com/vndev/gamebooster/
│   ├── MainActivity.java     # Giao diện, tương tác, tabs, session / DND
│   ├── DeviceStats.java      # Đọc số liệu thiết bị từ API công khai
│   ├── GameRepository.java   # Tìm ứng dụng có thể mở
│   ├── SessionStore.java     # Lưu phiên và lịch sử
│   └── RingView.java        # Đồ họa vòng RAM
├── app/src/main/res/        # Theme và icon vector
└── .github/workflows/build-apk.yml
```

## Kiểm thử và phát triển

Dự án được tạo ở môi trường không có Android SDK và chưa được biên dịch hay chạy trên thiết bị thực. Hãy kiểm thử đặc biệt các màn hình kích thước nhỏ, quyền DND trên Android 15+, và một số launcher OEM. Mọi chức năng sử dụng API Android công khai.

Tên hiển thị: **VN Game Booster**. Package: `com.vndev.gamebooster`. Version: `1.0.0`.


## Build nhanh trên Windows (1 cú nhấp)

Nếu máy tính **đã cài Android Studio và Android SDK API 35**, nhấp đúp `TAO_APK_1_CLICK.cmd`. Script tự tìm SDK, sử dụng Java của Android Studio và tải Gradle 8.9 từ trang chính thức trong lần đầu. Khi build thành công, file `VN-Game-Booster.apk` sẽ nằm ngay trong thư mục dự án. Cần Internet để Gradle tải Android Gradle Plugin lần đầu. Đây là APK **debug** được ký tự động, phục vụ cài đặt thử nghiệm.

Nếu không có Android Studio, dùng workflow GitHub Actions đi kèm như hướng dẫn ở trên, không cần SDK trên máy.
