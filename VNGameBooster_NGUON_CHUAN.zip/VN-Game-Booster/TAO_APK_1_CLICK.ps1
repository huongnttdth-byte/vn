# VN Game Booster: builds an installable signed DEBUG APK using official Gradle.
# Requirements: Android SDK 35 (Android Studio), Java 17+, Internet on first run.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try {
    $project = Split-Path -Parent $MyInvocation.MyCommand.Path
    Set-Location $project
    Write-Host '== VN Game Booster | Tao APK ==' -ForegroundColor Cyan

    # Resolve SDK from Android Studio's standard Windows location or environment.
    $sdkCandidates = @($env:ANDROID_SDK_ROOT, $env:ANDROID_HOME, "$env:LOCALAPPDATA\Android\Sdk")
    $sdk = $sdkCandidates | Where-Object { $_ -and (Test-Path (Join-Path $_ 'platforms\android-35\android.jar')) } | Select-Object -First 1
    if (-not $sdk) {
        throw 'Chua co Android SDK 35. Mo Android Studio > SDK Manager > cai Android 15.0 (API 35), sau do chay lai.'
    }
    $env:ANDROID_HOME = $sdk
    $env:ANDROID_SDK_ROOT = $sdk
    Write-Host "Android SDK: $sdk"

    # Prefer Android Studio's JBR (Java 17+), then JAVA_HOME or java from PATH.
    $javaCandidates = @(
        "$env:ProgramFiles\Android\Android Studio\jbr",
        $env:JAVA_HOME,
        "$env:ProgramFiles\Java\jdk-17",
        "$env:ProgramFiles\Microsoft\jdk-17"
    )
    $javaHome = $javaCandidates | Where-Object { $_ -and (Test-Path (Join-Path $_ 'bin\java.exe')) } | Select-Object -First 1
    if ($javaHome) {
        $env:JAVA_HOME = $javaHome
        $env:PATH = (Join-Path $javaHome 'bin') + ';' + $env:PATH
    } elseif (-not (Get-Command java.exe -ErrorAction SilentlyContinue)) {
        throw 'Can JDK 17 tro len. Cai Android Studio ban moi (co JBR) hoac JDK 17.'
    }
    & java.exe -version
    if ($LASTEXITCODE -ne 0) { throw 'Java khong chay duoc.' }

    $cache = Join-Path $env:LOCALAPPDATA 'VNGameBoosterBuild'
    $gradleHome = Join-Path $cache 'gradle-8.9'
    $gradle = Join-Path $gradleHome 'bin\gradle.bat'
    if (-not (Test-Path $gradle)) {
        New-Item -ItemType Directory -Path $cache -Force | Out-Null
        $archive = Join-Path $cache 'gradle-8.9-bin.zip'
        Write-Host 'Dang tai Gradle 8.9 tu trang chinh thuc (chi can lan dau)...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $archive -UseBasicParsing
        Expand-Archive -Path $archive -DestinationPath $cache -Force
        Remove-Item $archive -Force
    }
    if (-not (Test-Path $gradle)) { throw 'Khong cai duoc Gradle 8.9.' }

    Write-Host 'Dang build va ky debug APK ...' -ForegroundColor Cyan
    & $gradle --no-daemon --stacktrace assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle build loi (ma $LASTEXITCODE). Xem dong loi ben tren." }
    $apk = Join-Path $project 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path $apk)) { throw 'Gradle bao thanh cong nhung khong tim thay app-debug.apk.' }
    $dest = Join-Path $project 'VN-Game-Booster.apk'
    Copy-Item $apk $dest -Force
    Write-Host "TAO APK THANH CONG: $dest" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "LOI: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
