@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0TAO_APK_1_CLICK.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo [ERROR] Build did not complete. Review the message above.
) else (
  echo [OK] APK is in this folder: VN-Game-Booster.apk
)
pause
exit /b %RC%
